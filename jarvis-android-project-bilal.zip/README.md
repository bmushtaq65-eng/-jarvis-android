# JARVIS Personal Assistant - Native Android App

A futuristic, premium JARVIS-style assistant for Android built with **Kotlin**, **Jetpack Compose**, and **Material 3**.

- **Package Name**: `com.bilal.jarvis`
- **Minimum Android SDK**: 26 (Android 8.0 Oreo)
- **Target SDK**: 35 (Android 15)

---

## 🚀 Features Implemented (Version 1)

1. **Microphone Permission Handling**: Dynamic runtime permission requests via `ActivityResultContracts.RequestPermission()`.
2. **Android Speech Recognition**: Converts voice audio to text with real-time audio volume RMS dB metering.
3. **Android Text-To-Speech (TTS)**: Speaks responses aloud with British English locale tuning.
4. **Application Launcher**: Launches installed apps by name (YouTube, WhatsApp, Maps, Chrome, Spotify, Camera, Calculator) via `PackageManager` and `Intent.ACTION_MAIN`.
5. **Phone Dialer**: Dispatches `Intent.ACTION_DIAL` with target telephone numbers.
6. **WhatsApp Message Dispatching**: Prepares drafts via `api.whatsapp.com` and deep links; displays message preview and confirmation dialog before launching WhatsApp. Never falsely claims background delivery.
7. **Android Settings Access**: Opens Wi-Fi, Bluetooth, Battery, Display, Sound, and Main Settings screens via Android `Settings.ACTION_*` intents.
8. **Flashlight / Torch Control**: Hardware flashlight control using Android `CameraManager.setTorchMode`.
9. **Graceful Fallback**: Intelligent responses for unrecognized directives.
10. **Sensitive Action Confirmation**: Confirmation dialogs for phone calls, WhatsApp messages, and critical toggles.
11. **Platform Restriction Explanations**: Explains Android security constraints regarding reboot/shutdown, silent background messaging, and root access.

---

## 🛠️ How to Build and Generate the APK

### Method 1: Android Studio (Recommended)
1. Download the project ZIP or open the `android-project` folder.
2. Launch **Android Studio** (Koala, Ladybug, or newer).
3. Select **Open** and choose the project directory.
4. Wait for Gradle sync to complete.
5. In the top menu, go to **Build** > **Build Bundle(s) / APK(s)** > **Build APK(s)**.
6. Once compilation finishes, click **locate** or find your APK at:
   `app/build/outputs/apk/debug/app-debug.apk`

### Method 2: Command Line (Gradle)
Run the following in the project root:
```bash
# On Linux / macOS:
./gradlew assembleDebug

# On Windows:
gradlew.bat assembleDebug
```
The resulting APK will be located at:
`app/build/outputs/apk/debug/app-debug.apk`

To install directly onto a connected Android phone or emulator:
```
