package com.bilal.jarvis.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.bilal.jarvis.theme.JarvisCyanPrimary
import com.bilal.jarvis.theme.JarvisSurfaceVariant

@Composable
fun CommandInputBar(
    isListening: Boolean,
    onMicClick: () -> Unit,
    onSendCommand: (String) -> Unit
) {
    var textInput by remember { mutableStateOf("") }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Glowing Microphone button
        IconButton(
            onClick = onMicClick,
            modifier = Modifier
                .size(52.dp)
                .background(
                    color = if (isListening) Color(0xFFEF4444) else JarvisCyanPrimary,
                    shape = CircleShape
                )
        ) {
            Icon(
                imageVector = if (isListening) Icons.Default.MicOff else Icons.Default.Mic,
                contentDescription = "Voice Input",
                tint = Color.Black
            )
        }

        // Text command input field
        OutlinedTextField(
            value = textInput,
            onValueChange = { textInput = it },
            modifier = Modifier.weight(1f),
            placeholder = { Text("Enter directive or tap mic...", color = Color(0xFF64748B)) },
            shape = RoundedCornerShape(24.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = JarvisCyanPrimary,
                unfocusedBorderColor = Color(0xFF334155),
                focusedContainerColor = JarvisSurfaceVariant,
                unfocusedContainerColor = JarvisSurfaceVariant,
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White
            ),
            singleLine = true
        )

        // Send Button
        IconButton(
            onClick = {
                if (textInput.isNotBlank()) {
                    onSendCommand(textInput)
                    textInput = ""
                }
            },
            enabled = textInput.isNotBlank(),
            modifier = Modifier
                .size(48.dp)
                .background(
                    color = if (textInput.isNotBlank()) JarvisCyanPrimary else Color(0xFF1E293B),
                    shape = CircleShape
                )
        ) {
            Icon(
                imageVector = Icons.Default.Send,
                contentDescription = "Send",
                tint = if (textInput.isNotBlank()) Color.Black else Color.Gray
            )
        }
    }
}
