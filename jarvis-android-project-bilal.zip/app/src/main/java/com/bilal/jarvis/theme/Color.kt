package com.bilal.jarvis.theme

import androidx.compose.ui.graphics.Color

val JarvisBackground = Color(0xFF030712)
val JarvisSurface = Color(0xFF0B132B)
val JarvisSurfaceVariant = Color(0xFF1C2541)

val JarvisCyanPrimary = Color(0xFF00F2FE)
val JarvisCyanAccent = Color(0xFF4FACFE)
val JarvisCyanGlow = Color(0xFF00E5FF)
val JarvisCyanDark = Color(0xFF0A3641)

val JarvisTextPrimary = Color(0xFFE2E8F0)
val JarvisTextSecondary = Color(0xFF94A3B8)
val JarvisBorderCyan = Color(0x6600F2FE)

val JarvisWarning = Color(0xFFFFB703)
val JarvisError = Color(0xFFEF4444)
val JarvisSuccess = Color(0xFF10B981)
