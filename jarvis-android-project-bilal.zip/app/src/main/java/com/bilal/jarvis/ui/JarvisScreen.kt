package com.bilal.jarvis.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.bilal.jarvis.theme.JarvisBackground
import com.bilal.jarvis.theme.JarvisCyanPrimary
import com.bilal.jarvis.ui.components.ArcReactorIndicator
import com.bilal.jarvis.ui.components.CommandInputBar
import com.bilal.jarvis.ui.components.ConfirmationDialog
import com.bilal.jarvis.ui.components.MessageList
import com.bilal.jarvis.ui.viewmodel.JarvisViewModel

@Composable
fun JarvisScreen(
    viewModel: JarvisViewModel,
    onRequestRecordAudio: () -> Unit
) {
    val jarvisState by viewModel.jarvisState.collectAsState()
    val messages by viewModel.messages.collectAsState()
    val audioLevel by viewModel.audioLevel.collectAsState()
    val pendingConfirmation by viewModel.pendingConfirmation.collectAsState()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(JarvisBackground)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Futuristic HUD Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "J.A.R.V.I.S.",
                    style = MaterialTheme.typography.headlineMedium,
                    color = JarvisCyanPrimary
                )
                Surface(
                    color = Color(0xFF0F2633),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(
                        text = "STATUS: ${jarvisState.name}",
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                        style = MaterialTheme.typography.labelSmall,
                        color = JarvisCyanPrimary
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Animated Arc Reactor Voice Indicator
            ArcReactorIndicator(
                state = jarvisState,
                audioLevel = audioLevel,
                onClick = onRequestRecordAudio
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Conversation Stream
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                MessageList(messages = messages)
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Command Input Bar (Mic + Text)
            CommandInputBar(
                isListening = jarvisState.name == "LISTENING",
                onMicClick = onRequestRecordAudio,
                onSendCommand = { viewModel.submitTextCommand(it) }
            )
        }

        // Sensitive Action Confirmation Dialog (Dialer & WhatsApp pre-send)
        pendingConfirmation?.let { confirmation ->
            ConfirmationDialog(
                title = confirmation.title,
                description = confirmation.description,
                details = confirmation.details,
                warning = confirmation.warning,
                confirmText = confirmation.confirmButtonText,
                onConfirm = confirmation.onConfirm,
                onDismiss = confirmation.onDismiss
            )
        }
    }
}
