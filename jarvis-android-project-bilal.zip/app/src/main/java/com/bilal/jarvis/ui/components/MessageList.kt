package com.bilal.jarvis.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.bilal.jarvis.theme.JarvisBorderCyan
import com.bilal.jarvis.theme.JarvisCyanPrimary
import com.bilal.jarvis.ui.viewmodel.JarvisMessage

@Composable
fun MessageList(messages: List<JarvisMessage>) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        reverseLayout = false,
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(messages, key = { it.id }) { msg ->
            val isUser = msg.sender == "USER"
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = if (isUser) Alignment.End else Alignment.Start
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth(0.85f)
                        .background(
                            color = if (isUser) Color(0xFF132238) else Color(0xFF091422),
                            shape = RoundedCornerShape(12.dp)
                        )
                        .border(
                            width = 1.dp,
                            color = if (isUser) Color(0xFF38BDF8) else JarvisBorderCyan,
                            shape = RoundedCornerShape(12.dp)
                        )
                        .padding(12.dp)
                ) {
                    Column {
                        Text(
                            text = if (isUser) "COMMAND PROMPT" else "J.A.R.V.I.S.",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (isUser) Color(0xFF38BDF8) else JarvisCyanPrimary
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = msg.text,
                            style = MaterialTheme.typography.bodyLarge,
                            color = Color(0xFFF1F5F9)
                        )
                    }
                }
            }
        }
    }
}
