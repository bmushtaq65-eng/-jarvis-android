package com.bilal.jarvis.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.bilal.jarvis.theme.JarvisCyanPrimary
import com.bilal.jarvis.ui.viewmodel.JarvisState

@Composable
fun ArcReactorIndicator(
    state: JarvisState,
    audioLevel: Float,
    onClick: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "arc_reactor")
    val rotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 8000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotation"
    )

    val counterRotation by infiniteTransition.animateFloat(
        initialValue = 360f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 6000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "counter_rotation"
    )

    val pulse by infiniteTransition.animateFloat(
        initialValue = 0.9f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    Box(
        modifier = Modifier
            .size(190.dp)
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(180.dp)) {
            val center = Offset(size.width / 2f, size.height / 2f)
            val baseRadius = size.minDimension / 2.3f

            // Audio level amplification
            val dynamicRadius = baseRadius * (if (state == JarvisState.LISTENING) (1f + audioLevel * 0.25f) else 1f)

            // Outer dashed HUD ring
            drawCircle(
                color = JarvisCyanPrimary.copy(alpha = 0.35f),
                radius = dynamicRadius,
                center = center,
                style = Stroke(
                    width = 2.dp.toPx(),
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(15f, 15f), rotation)
                )
            )

            // Inner counter-rotating ring
            drawCircle(
                color = Color(0xFF4FACFE).copy(alpha = 0.5f),
                radius = dynamicRadius * 0.75f,
                center = center,
                style = Stroke(
                    width = 3.dp.toPx(),
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(25f, 20f), counterRotation)
                )
            )

            // Center Arc Reactor Core with pulsing glow
            val corePulse = if (state == JarvisState.SPEAKING || state == JarvisState.LISTENING) pulse else 1f
            drawCircle(
                color = JarvisCyanPrimary.copy(alpha = 0.85f),
                radius = (dynamicRadius * 0.35f) * corePulse,
                center = center
            )

            drawCircle(
                color = Color.White,
                radius = (dynamicRadius * 0.18f) * corePulse,
                center = center
            )
        }
    }
}
