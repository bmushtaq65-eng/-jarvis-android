package com.bilal.jarvis.service

/**
 * Interface for AI response generation.
 * Can be implemented by local offline models or future cloud LLM APIs (e.g. Gemini).
 */
interface AiService {
    suspend fun getResponse(query: String): String
}
