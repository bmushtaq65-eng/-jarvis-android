package com.bilal.jarvis

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.core.content.ContextCompat
import com.bilal.jarvis.theme.JarvisTheme
import com.bilal.jarvis.ui.JarvisScreen
import com.bilal.jarvis.ui.viewmodel.JarvisViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: JarvisViewModel by viewModels()

    // Activity Result Launcher for RECORD_AUDIO runtime permission
    private val requestRecordAudioLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            viewModel.startVoiceRecognition()
        } else {
            Toast.makeText(
                this,
                "Microphone permission is required for voice commands.",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            JarvisTheme {
                JarvisScreen(
                    viewModel = viewModel,
                    onRequestRecordAudio = { checkAndRequestMicPermission() }
                )
            }
        }
    }

    private fun checkAndRequestMicPermission() {
        when {
            ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.RECORD_AUDIO
            ) == PackageManager.PERMISSION_GRANTED -> {
                viewModel.startVoiceRecognition()
            }
            shouldShowRequestPermissionRationale(Manifest.permission.RECORD_AUDIO) -> {
                Toast.makeText(
                    this,
                    "JARVIS requires microphone access to process voice commands.",
                    Toast.LENGTH_LONG
                ).show()
                requestRecordAudioLauncher.launch(Manifest.permission.RECORD_AUDIO)
            }
            else -> {
                requestRecordAudioLauncher.launch(Manifest.permission.RECORD_AUDIO)
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        viewModel.cleanup()
    }
}
