package com.bilal.jarvis.service

import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraAccessException
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.provider.Settings
import android.widget.Toast
import java.net.URLEncoder

class AndroidActionExecutor(private val context: Context) {

    private val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as? CameraManager
    private var cameraId: String? = null
    var isFlashlightOn: Boolean = false
        private set

    init {
        try {
            cameraId = cameraManager?.cameraIdList?.firstOrNull()
        } catch (_: Exception) {}
    }

    fun openDialer(phoneNumber: String): Boolean {
        return try {
            val intent = Intent(Intent.ACTION_DIAL).apply {
                data = Uri.parse("tel:$phoneNumber")
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
            true
        } catch (e: Exception) {
            Toast.makeText(context, "Could not open dialer: ${e.message}", Toast.LENGTH_SHORT).show()
            false
        }
    }

    /**
     * Requirement 6: Prepare a WhatsApp message using intent or deep link.
     * Shows message in confirmation first; does not claim sent automatically.
     */
    fun openWhatsAppMessage(recipient: String, message: String): Boolean {
        return try {
            val cleanPhone = recipient.replace(Regex("[^0-9]"), "")
            val encodedMessage = URLEncoder.encode(message, "UTF-8")
            
            val uri = if (cleanPhone.isNotBlank()) {
                Uri.parse("https://api.whatsapp.com/send?phone=$cleanPhone&text=$encodedMessage")
            } else {
                Uri.parse("https://api.whatsapp.com/send?text=$encodedMessage")
            }

            val intent = Intent(Intent.ACTION_VIEW, uri).apply {
                setPackage("com.whatsapp")
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }

            // Fallback to browser or any handler if WhatsApp package isn't strictly found
            try {
                context.startActivity(intent)
            } catch (_: Exception) {
                val genericIntent = Intent(Intent.ACTION_VIEW, uri).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(genericIntent)
            }
            true
        } catch (e: Exception) {
            Toast.makeText(context, "Failed to launch WhatsApp: ${e.message}", Toast.LENGTH_SHORT).show()
            false
        }
    }

    fun toggleFlashlight(targetState: Boolean?): Boolean {
        val manager = cameraManager ?: return false
        val id = cameraId ?: return false
        val newState = targetState ?: !isFlashlightOn

        return try {
            manager.setTorchMode(id, newState)
            isFlashlightOn = newState
            true
        } catch (e: CameraAccessException) {
            Toast.makeText(context, "Camera torch inaccessible: ${e.message}", Toast.LENGTH_SHORT).show()
            false
        } catch (e: Exception) {
            Toast.makeText(context, "Flashlight error: ${e.message}", Toast.LENGTH_SHORT).show()
            false
        }
    }

    fun openAppByName(appName: String): Boolean {
        val pm = context.packageManager
        val clean = appName.lowercase()

        // Quick common package dictionary
        val knownPackages = mapOf(
            "whatsapp" to "com.whatsapp",
            "youtube" to "com.google.android.youtube",
            "maps" to "com.google.android.apps.maps",
            "camera" to "com.google.android.GoogleCamera",
            "chrome" to "com.android.chrome",
            "settings" to "com.android.settings",
            "calculator" to "com.google.android.calculator",
            "gmail" to "com.google.android.gm",
            "spotify" to "com.spotify.music"
        )

        val targetPackage = knownPackages[clean]
        if (targetPackage != null) {
            val intent = pm.getLaunchIntentForPackage(targetPackage)
            if (intent != null) {
                intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                context.startActivity(intent)
                return true
            }
        }

        // Fuzzy match installed packages
        val installedApps = pm.getInstalledApplications(0)
        for (app in installedApps) {
            val label = pm.getApplicationLabel(app).toString().lowercase()
            if (label.contains(clean) || clean.contains(label)) {
                val launchIntent = pm.getLaunchIntentForPackage(app.packageName)
                if (launchIntent != null) {
                    launchIntent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    context.startActivity(launchIntent)
                    return true
                }
            }
        }

        Toast.makeText(context, "Could not find application: $appName", Toast.LENGTH_SHORT).show()
        return false
    }

    fun openSettingsScreen(type: String): Boolean {
        val action = when (type) {
            "wifi" -> Settings.ACTION_WIFI_SETTINGS
            "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
            "battery" -> Settings.ACTION_BATTERY_SAVER_SETTINGS
            "display" -> Settings.ACTION_DISPLAY_SETTINGS
            "sound" -> Settings.ACTION_SOUND_SETTINGS
            else -> Settings.ACTION_SETTINGS
        }

        return try {
            val intent = Intent(action).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
            true
        } catch (e: Exception) {
            Toast.makeText(context, "Settings screen unavailable: ${e.message}", Toast.LENGTH_SHORT).show()
            false
        }
    }
}
