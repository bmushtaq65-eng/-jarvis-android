package com.bilal.jarvis.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.bilal.jarvis.service.AndroidActionExecutor
import com.bilal.jarvis.service.CommandParser
import com.bilal.jarvis.service.MockAiService
import com.bilal.jarvis.service.ParsedAction
import com.bilal.jarvis.service.TextToSpeechService
import com.bilal.jarvis.service.VoiceRecognitionService
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class JarvisState {
    IDLE,
    LISTENING,
    PROCESSING,
    SPEAKING
}

data class JarvisMessage(
    val id: String = java.util.UUID.randomUUID().toString(),
    val sender: String, // "USER" or "JARVIS"
    val text: String,
    val timestamp: Long = System.currentTimeMillis()
)

data class PendingConfirmation(
    val title: String,
    val description: String,
    val details: List<Pair<String, String>>,
    val warning: String? = null,
    val confirmButtonText: String,
    val onConfirm: () -> Unit,
    val onDismiss: () -> Unit
)

class JarvisViewModel(application: Application) : AndroidViewModel(application) {

    private val voiceService = VoiceRecognitionService(application)
    private val ttsService = TextToSpeechService(application)
    private val commandParser = CommandParser()
    private val actionExecutor = AndroidActionExecutor(application)
    private val aiService = MockAiService()

    private val _jarvisState = MutableStateFlow(JarvisState.IDLE)
    val jarvisState: StateFlow<JarvisState> = _jarvisState.asStateFlow()

    private val _messages = MutableStateFlow<List<JarvisMessage>>(listOf(
        JarvisMessage(
            sender = "JARVIS",
            text = "J.A.R.V.I.S. online. All Android subsystems initialized. Standing by for voice or text command, sir."
        )
    ))
    val messages: StateFlow<List<JarvisMessage>> = _messages.asStateFlow()

    private val _audioLevel = MutableStateFlow(0f)
    val audioLevel: StateFlow<Float> = _audioLevel.asStateFlow()

    private val _pendingConfirmation = MutableStateFlow<PendingConfirmation?>(null)
    val pendingConfirmation: StateFlow<PendingConfirmation?> = _pendingConfirmation.asStateFlow()

    private val _isFlashlightOn = MutableStateFlow(false)
    val isFlashlightOn: StateFlow<Boolean> = _isFlashlightOn.asStateFlow()

    fun startVoiceRecognition() {
        if (_jarvisState.value == JarvisState.LISTENING) {
            voiceService.stopListening()
            _jarvisState.value = JarvisState.IDLE
            return
        }

        _jarvisState.value = JarvisState.LISTENING
        ttsService.stop()

        voiceService.startListening(
            onResult = { recognizedText ->
                processCommand(recognizedText)
            },
            onError = { errorMsg ->
                _jarvisState.value = JarvisState.IDLE
                addMessage("JARVIS", "Voice input alert: $errorMsg")
            },
            onRmsChanged = { level ->
                _audioLevel.value = level
            }
        )
    }

    fun stopVoiceRecognition() {
        voiceService.stopListening()
        _jarvisState.value = JarvisState.IDLE
        _audioLevel.value = 0f
    }

    fun submitTextCommand(commandText: String) {
        if (commandText.isBlank()) return
        processCommand(commandText)
    }

    private fun processCommand(commandText: String) {
        voiceService.stopListening()
        _jarvisState.value = JarvisState.PROCESSING

        addMessage("USER", commandText)

        viewModelScope.launch {
            when (val action = commandParser.parse(commandText)) {
                is ParsedAction.PhoneDial -> {
                    // Requirement 10: Show confirmation screen before sensitive action
                    _pendingConfirmation.value = PendingConfirmation(
                        title = "Confirm Phone Call",
                        description = "Opening Android Phone Dialer to initiate voice call.",
                        details = listOf(
                            "Contact / Target" to action.contactName,
                            "Phone Number" to action.number,
                            "Action Protocol" to "Android Intent: ACTION_DIAL"
                        ),
                        warning = "Verify the telephone destination before launching the dialer.",
                        confirmButtonText = "Launch Dialer",
                        onConfirm = {
                            _pendingConfirmation.value = null
                            actionExecutor.openDialer(action.number)
                            respondWithVoice("Opening phone dialer with ${action.number}.")
                        },
                        onDismiss = {
                            _pendingConfirmation.value = null
                            respondWithVoice("Call protocol aborted.")
                        }
                    )
                }

                is ParsedAction.PrepareWhatsApp -> {
                    // Requirement 6 & 10: Prepare WhatsApp message, show before opening, do not claim sent automatically
                    _pendingConfirmation.value = PendingConfirmation(
                        title = "Verify WhatsApp Dispatch",
                        description = "Per Android security specifications, JARVIS prepares the draft and opens WhatsApp. Android security does not allow silent automatic background sending.",
                        details = listOf(
                            "Recipient" to action.recipient,
                            "Message Content" to action.message,
                            "Delivery Notice" to "You must press send inside WhatsApp"
                        ),
                        warning = "The message has NOT been sent yet. Confirm to open WhatsApp with your prepared text.",
                        confirmButtonText = "Open in WhatsApp",
                        onConfirm = {
                            _pendingConfirmation.value = null
                            actionExecutor.openWhatsAppMessage(action.recipient, action.message)
                            respondWithVoice("Opening WhatsApp with your draft for ${action.recipient}.")
                        },
                        onDismiss = {
                            _pendingConfirmation.value = null
                            respondWithVoice("WhatsApp dispatch canceled.")
                        }
                    )
                }

                is ParsedAction.Flashlight -> {
                    val success = actionExecutor.toggleFlashlight(action.targetState)
                    _isFlashlightOn.value = actionExecutor.isFlashlightOn
                    respondWithVoice(if (success) action.speechReply else "Optical emitter unavailable on this device.")
                }

                is ParsedAction.LaunchApp -> {
                    actionExecutor.openAppByName(action.appName)
                    respondWithVoice(action.speechReply)
                }

                is ParsedAction.OpenSetting -> {
                    actionExecutor.openSettingsScreen(action.settingName)
                    respondWithVoice(action.speechReply)
                }

                is ParsedAction.RestrictionNotice -> {
                    respondWithVoice(action.explanation)
                }

                is ParsedAction.AiChat -> {
                    val reply = aiService.getResponse(action.query)
                    respondWithVoice(reply)
                }
            }
        }
    }

    private fun respondWithVoice(reply: String) {
        addMessage("JARVIS", reply)
        _jarvisState.value = JarvisState.SPEAKING
        ttsService.speak(reply) {
            _jarvisState.value = JarvisState.IDLE
        }
    }

    private fun addMessage(sender: String, text: String) {
        _messages.update { current ->
            current + JarvisMessage(sender = sender, text = text)
        }
    }

    fun cleanup() {
        voiceService.destroy()
        ttsService.shutdown()
    }
}
