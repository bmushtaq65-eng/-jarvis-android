package com.bilal.jarvis.service

import java.util.Locale

sealed class ParsedAction {
    data class LaunchApp(val appName: String, val speechReply: String) : ParsedAction()
    data class PhoneDial(val number: String, val contactName: String) : ParsedAction()
    data class PrepareWhatsApp(val recipient: String, val message: String) : ParsedAction()
    data class Flashlight(val targetState: Boolean?, val speechReply: String) : ParsedAction()
    data class OpenSetting(val settingName: String, val speechReply: String) : ParsedAction()
    data class RestrictionNotice(val explanation: String) : ParsedAction()
    data class AiChat(val query: String) : ParsedAction()
}

class CommandParser {

    fun parse(input: String): ParsedAction {
        val raw = input.trim()
        val lower = raw.lowercase(Locale.ROOT)

        // 1. Android Permission & Security Restrictions
        if (lower.contains("restart") || lower.contains("reboot") ||
            lower.contains("shut down") || lower.contains("power off")) {
            return ParsedAction.RestrictionNotice(
                "Android security architecture strictly restricts third-party apps from powering down or restarting the phone. This requires elevated system or root access, which Android intentionally blocks for user safety."
            )
        }

        if (lower.contains("silent whatsapp") || lower.contains("send automatically without opening") ||
            lower.contains("send background sms")) {
            return ParsedAction.RestrictionNotice(
                "In compliance with Android security sandboxing, applications cannot dispatch WhatsApp messages silently in the background without user review. JARVIS will prepare your draft and open WhatsApp for your explicit send confirmation."
            )
        }

        if (lower.contains("root") || lower.contains("hack") || lower.contains("read private")) {
            return ParsedAction.RestrictionNotice(
                "Access restricted. JARVIS operates within certified Android API boundaries and does not employ root exploits or hidden accessibility bypasses."
            )
        }

        // 2. WhatsApp Messaging
        if (lower.startsWith("send whatsapp") || lower.startsWith("whatsapp") || lower.contains("message on whatsapp")) {
            return parseWhatsApp(raw)
        }

        // 3. Phone Dialer
        if (lower.startsWith("call ") || lower.startsWith("dial ") || lower.startsWith("phone ")) {
            return parsePhoneDial(raw)
        }

        // 4. Flashlight
        if (lower.contains("flashlight") || lower.contains("torch")) {
            val turnOn = lower.contains("on") || lower.contains("enable") || lower.contains("activate")
            val turnOff = lower.contains("off") || lower.contains("disable") || lower.contains("deactivate")
            val targetState: Boolean? = if (turnOff) false else if (turnOn) true else null
            val reply = when (targetState) {
                true -> "Illuminating optical emitter. Flashlight activated."
                false -> "Extinguishing optical emitter. Flashlight deactivated."
                null -> "Toggling flashlight emitter state."
            }
            return ParsedAction.Flashlight(targetState, reply)
        }

        // 5. Settings Screens
        if (lower.contains("setting") || lower.contains("wifi") || lower.contains("wi-fi") ||
            lower.contains("bluetooth") || lower.contains("battery") || lower.contains("display") || lower.contains("sound")) {
            return parseSettings(lower)
        }

        // 6. Open Apps
        if (lower.startsWith("open ") || lower.startsWith("launch ") || lower.startsWith("start ")) {
            val appName = raw.replace(Regex("^(open|launch|start)\\s+", RegexOption.IGNORE_CASE), "")
                .replace(Regex("(app|application)$", RegexOption.IGNORE_CASE), "")
                .trim()
            return ParsedAction.LaunchApp(
                appName = appName,
                speechReply = "Launching $appName, sir."
            )
        }

        // Default to AI conversational intelligence
        return ParsedAction.AiChat(raw)
    }

    private fun parseWhatsApp(raw: String): ParsedAction {
        // Pattern: "whatsapp [recipient] saying [message]"
        val regex = Regex("(?:whatsapp|send whatsapp)(?:\\s+to)?\\s+([^\\s]+)(?:\\s+(?:saying|with message|message)\\s+)(.+)", RegexOption.IGNORE_CASE)
        val match = regex.find(raw)

        return if (match != null) {
            val recipient = match.groupValues[1]
            val message = match.groupValues[2]
            ParsedAction.PrepareWhatsApp(recipient, message)
        } else {
            val trimmed = raw.replace(Regex("^(send\\s+whatsapp\\s+to|send\\s+whatsapp|whatsapp)\\s*", RegexOption.IGNORE_CASE), "")
            val parts = trimmed.split(" ", limit = 2)
            val recipient = parts.firstOrNull()?.ifBlank { "Contact" } ?: "Contact"
            val message = if (parts.size > 1) parts[1] else "Hello from JARVIS"
            ParsedAction.PrepareWhatsApp(recipient, message)
        }
    }

    private fun parsePhoneDial(raw: String): ParsedAction {
        val numberRegex = Regex("(\\+?[0-9\\s-]{3,16})")
        val numberMatch = numberRegex.find(raw)
        val number = numberMatch?.value?.replace("\\s".toRegex(), "") ?: "555-0199"
        val name = raw.replace(Regex("^(call|dial|phone)\\s*", RegexOption.IGNORE_CASE), "").trim()
        return ParsedAction.PhoneDial(number = number, contactName = name.ifBlank { number })
    }

    private fun parseSettings(lower: String): ParsedAction {
        val (screen, reply) = when {
            lower.contains("wifi") || lower.contains("wi-fi") -> "wifi" to "Opening Wi-Fi configuration."
            lower.contains("bluetooth") -> "bluetooth" to "Opening Bluetooth configuration."
            lower.contains("battery") -> "battery" to "Opening Battery & Power screen."
            lower.contains("display") -> "display" to "Opening Display & Brightness settings."
            lower.contains("sound") -> "sound" to "Opening Audio & Notification settings."
            else -> "settings" to "Opening Android Settings."
        }
        return ParsedAction.OpenSetting(screen, reply)
    }
}
