package com.bilal.jarvis.service

import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MockAiService : AiService {

    private val knowledgeBase = mapOf(
        "hello" to "Greetings, sir. All core protocols are operational and awaiting your instruction.",
        "hi" to "Good day. How may I assist you today?",
        "how are you" to "Functioning at optimal capacity, sir. All background diagnostics report nominal status.",
        "status" to "Core system: ONLINE. Voice analyzer: CALIBRATED. Android intent bus: READY.",
        "who are you" to "I am J.A.R.V.I.S., your Just A Rather Very Intelligent System personal assistant, crafted by Bilal in Jetpack Compose.",
        "who made you" to "I was designed and programmed by Bilal using modern Kotlin, Jetpack Compose, and Material 3.",
        "tell me a joke" to "Why do programmers prefer dark mode? Because light attracts bugs. Classic human observation, sir.",
        "thank you" to "Always a pleasure to be of service, sir.",
        "thanks" to "You are most welcome, sir.",
        "goodbye" to "Standing by in low-power surveillance mode. Voice listener ready whenever you are."
    )

    override suspend fun getResponse(query: String): String {
        // High-tech neural delay simulation
        delay(350)

        val clean = query.trim().lowercase(Locale.ROOT)

        for ((key, response) in knowledgeBase) {
            if (clean.contains(key)) {
                return response
            }
        }

        if (clean.contains("time")) {
            val time = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date())
            return "Current system timestamp is $time, sir."
        }

        if (clean.contains("date")) {
            val date = SimpleDateFormat("EEEE, MMMM d, yyyy", Locale.getDefault()).format(Date())
            return "Today is $date."
        }

        return "Query processed: \"$query\". My local offline heuristics do not contain a specialized action for this phrase. I have logged it for neural expansion."
    }
}
